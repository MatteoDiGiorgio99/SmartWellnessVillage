package it.unipr.digiorgio.smartvillage.server.resources;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.json.JSONObject;

/**
 * The {@code TemperatureSensor} class in Java represents a CoAP resource for monitoring and updating
 * temperature values with periodic updates.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class TemperatureSensor extends CoapResource {

    private double temperature;

    /**
     * Constructs a new instance of the {@code TemperatureSensor} class with the
     * specified name and initial temperature.
     * 
     * @param name               the name of the resource
     * @param initialTemperature the initial temperature
     */
    public TemperatureSensor(String name, double initialTemperature) {
        super(name);
        this.temperature = initialTemperature;
        Timer timer = new Timer();
        timer.schedule(new UpdateTask(this), 10000, 30000);
    }

    @Override
    public void handleGET(CoapExchange exchange) {
        // Respond with the current temperature value
        JSONObject jsonResponse = new JSONObject();
        jsonResponse.put("Temperature", temperature);
        exchange.respond(ResponseCode.CONTENT, jsonResponse.toString(), MediaTypeRegistry.APPLICATION_JSON);
    }

    @Override
    public void handlePOST(CoapExchange exchange) {
        String payload = exchange.getRequestText();
        try {
            // Parse the JSON payload and set the new temperature value
            JSONObject jsonPayload = new JSONObject(payload);
            double newTemp = jsonPayload.getDouble("Temperature");
            System.out.println("\u001B[32mTemperature set to: " + newTemp + " °C\u001B[0m");
            setTemperature(newTemp);
            exchange.respond(ResponseCode.CHANGED, "Temperature updated");
        } catch (NumberFormatException e) {
            exchange.respond(ResponseCode.BAD_REQUEST, "Invalid temperature value");
        }
    }

    /**
     * Sets the temperature value to the specified value.
     * 
     * @param temperature the new temperature value
     */
    public void setTemperature(double temperature) {
        this.temperature = temperature;
        changed();
    }

    /**
     * Gets the temperature value.
     * 
     * @return the temperature value
     */
    public double getTemperature() {
        return temperature;
    }

    /**
     * The {@code UpdateTask} class in Java represents a task that periodically
     * updates the temperature value of a temperature sensor.
     * 
     * @see TimerTask
     */
    private class UpdateTask extends TimerTask {
        private TemperatureSensor context = null;

        public UpdateTask(TemperatureSensor context) {
            this.context = context;
        }

        @Override
        public void run() {
            this.context.temperature = temperature - 1.5;
            this.context.changed();
            System.out.println("\u001B[33mTemperature decreased to: " + this.context.temperature + " °C\u001B[0m");
        }
    }
}
