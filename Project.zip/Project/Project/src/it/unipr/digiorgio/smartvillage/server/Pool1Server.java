package it.unipr.digiorgio.smartvillage.server;

import org.eclipse.californium.core.CoapServer;
import it.unipr.digiorgio.smartvillage.server.resources.ChlorineSensor;
import it.unipr.digiorgio.smartvillage.server.resources.TemperatureSensor;


/**
 * The  {@code Pool1Server} class extends CoapServer and sets up temperature and chlorine sensors for an Olympic pool.
 * The server is running on port 5684.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class Pool1Server extends CoapServer {

    public static void main(String[] args) {

        CoapServer server = new CoapServer(5684);

        // Olympic pool
        TemperatureSensor tempSensor1 = new TemperatureSensor("temperature1", 28.0);
        ChlorineSensor chlorineSensor1 = new ChlorineSensor("chlorine1", 2);

        // Set observable
        tempSensor1.setObservable(true);
        tempSensor1.getAttributes().setObservable();

        chlorineSensor1.setObservable(true);
        chlorineSensor1.getAttributes().setObservable();

        // Add resources to the server
        server.add(tempSensor1);
        server.add(chlorineSensor1);

        server.start();
        System.out.println("Pool1Server is running...");
    }
}
