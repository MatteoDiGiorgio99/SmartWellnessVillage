package it.unipr.digiorgio.smartvillage.client;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Request;
import org.json.JSONObject;
import org.eclipse.californium.core.coap.CoAP.Code;

import java.util.Random;

/**
 * The {@code SmartVillageMember} class simulates members entering and exiting a village using CoAP requests
 * with certain probabilities.
 * 
 * The SmartVillageMember class is a CoAP client that sends POST requests to the entry and exit resources
 * with a JSON payload containing the member ID. The class simulates members entering and exiting the village
 * with probabilities of 70% and 30%, respectively.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class SmartVillageMember {

    private static final String ENTRY_URL = "coap://localhost:5683/entry";
    private static final String EXIT_URL = "coap://localhost:5683/exit";
    private static final Random random = new Random();

    public static void main(String[] args) throws InterruptedException {
        while (true) {
            // Thread.sleep(3000);
            // Simulate members entering and exiting with certain probabilities
            if (shouldMemberEnter()) {
                String memberId = generateRandomMemberId();
                enterVillage(memberId);
            }

            if (shouldMemberExit()) {
                String memberId = generateRandomMemberId();
                exitVillage(memberId);
            }
            Thread.sleep(10000);
        }
    }

    /**
     * Simulate a member entering the village with a 70% probability.
     * 
     * @return true if the member should enter, false otherwise
     */
    private static boolean shouldMemberEnter() {
        // 70% probability to enter
        return random.nextDouble() < 0.7;
    }

    /**
     * Simulate a member exiting the village with a 30% probability.
     * 
     * @return true if the member should exit, false otherwise
     */
    private static boolean shouldMemberExit() {
        // 30% probability to exit
        return random.nextDouble() < 0.3;
    }

    /**
     * Generate a random member ID.
     * 
     * @return a random member ID
     */
    private static String generateRandomMemberId() {
        int randomId = random.nextInt(30);
        return "member-" + randomId;
    }

    /**
     * Send a POST request to the entry resource with the member ID.
     * 
     * @param memberId the member ID
     */
    private static void enterVillage(String memberId) {
        CoapClient client = new CoapClient(ENTRY_URL);

        // Create a POST request
        Request request = new Request(Code.POST);
        JSONObject jsonPayload = new JSONObject();
        jsonPayload.put("memberId", memberId);
        request.setPayload(jsonPayload.toString());
        request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

        // Send the POST request
        CoapResponse coapResp = client.advanced(request);
        System.out.println(coapResp.getResponseText());
    }

    /**
     * Send a POST request to the exit resource with the member ID.
     * 
     * @param memberId the member ID
     */
    private static void exitVillage(String memberId) {
        CoapClient client = new CoapClient(EXIT_URL);

        // Create a POST request
        Request request = new Request(Code.POST);
        JSONObject jsonPayload = new JSONObject();
        jsonPayload.put("memberId", memberId);
        request.setPayload(jsonPayload.toString());
        request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

        // Send the POST request
        CoapResponse coapResp = client.advanced(request);
        System.out.println(coapResp.getResponseText());
    }
}
