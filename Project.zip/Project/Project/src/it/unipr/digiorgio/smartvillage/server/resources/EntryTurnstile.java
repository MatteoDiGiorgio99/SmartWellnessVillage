package it.unipr.digiorgio.smartvillage.server.resources;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.json.JSONObject;

import it.unipr.digiorgio.smartvillage.server.MemberList;

/**
 * The {@code EntryTurnstile} class represents a CoAP resource for managing entry turnstile operations in a
 * smart village server, including handling entry recording for members and managing the turnstile state.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class EntryTurnstile extends CoapResource {

	private static int totalEntries; // static variable to keep track of total entries
	private boolean isDown; // variable to keep track of turnstile state
	private static final double DOWN_PROBABILITY = 0.1; // probability of turnstile going down
	private Random random;
	private String memberId; // variable to keep track of member ID
	private boolean manualOverride; // variable to keep track of manual override

	public EntryTurnstile(String name) {
		super(name);
		totalEntries = 0;
		isDown = false;
		random = new Random();
		manualOverride = false;
		Timer timer = new Timer();
		timer.schedule(new UpdateTask(this), 0, 5000);
	}

	@Override
	public void handlePOST(CoapExchange exchange) {
		String payload = exchange.getRequestText();
		JSONObject jsonPayload = new JSONObject(payload);
		setMemberId(jsonPayload.getString("memberId"));
		MemberList memberIds = MemberList.getInstance(); // get the singleton instance of MemberList

		if (getMemberId() == null || getMemberId().isEmpty()) {
			exchange.respond(ResponseCode.BAD_REQUEST, "\033[0;31mError:\033[0m Member ID required");
		} else {
			if (memberIds.isMemberPresent(getMemberId())) {
				exchange.respond(ResponseCode.FORBIDDEN, "\033[0;31mError:\033[0m Member ID " + getMemberId() + " is already inside.");
			} else {
				if (!jsonPayload.has("manualOverride") && isDown()) {
					exchange.respond(ResponseCode.SERVICE_UNAVAILABLE,
							"EntryTurnstile is down. Member: " + getMemberId() + " request sent to ManagerB.");
					setManualOverride(true); // set manual override to true
				} else {
					memberIds.addMember(getMemberId());
					incrementTotalEntries();
					exchange.respond(
							"\033[0;32mEntry\033[0m recorded for member ID: " + getMemberId());
					
					
				}
			}
		}
	}

	@Override
	public void handleGET(CoapExchange exchange) {
		// if the turnstile is down and manual override is set, send a response to the
		// client
		if (isDown() && isManualOverride()) {
			JSONObject jsonResponse = new JSONObject();
			jsonResponse.put("memberId", getMemberId());
			exchange.respond(ResponseCode.SERVICE_UNAVAILABLE, jsonResponse.toString(),
					MediaTypeRegistry.APPLICATION_JSON);
			setManualOverride(false);
		} else {
			JSONObject jsonResponse = new JSONObject();
			jsonResponse.put("Total Entries", getTotalEntries());
			exchange.respond(ResponseCode.CONTENT, jsonResponse.toString(), MediaTypeRegistry.APPLICATION_JSON);
		}
	}

	/**
	 * Method to get the total entries
	 * 
	 * @return totalEntries total entries
	 */
	public static int getTotalEntries() {
		return totalEntries;
	}

	/**
	 * Method to increment the total entries
	 * 
	 */
	public static void incrementTotalEntries() {
		totalEntries++;
	}

	/**
	 * State of the turnstile
	 * 
	 * @return isDown boolean value of turnstile state
	 */
	public boolean isDown() {
		return isDown;
	}

	/**
	 * Set state of the turnstile
	 * 
	 * @param down boolean value of turnstile state
	 */
	public void setDown(boolean down) {
		isDown = down;
	}

	/**
	 * Method to get the member ID
	 * 
	 * @return memberId member ID
	 */
	public String getMemberId() {
		return memberId;
	}

	/**
	 * Method to set the member ID
	 * 
	 * @param memberId member ID
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * Method to get the manual override
	 * 
	 * @return manualOverride manual override
	 */
	public boolean isManualOverride() {
		return manualOverride;
	}

	/**
	 * Method to set the manual override
	 * 
	 * @param manualOverride manual override
	 */
	public void setManualOverride(boolean manualOverride) {
		this.manualOverride = manualOverride;
	}

	/**
	 * The {@code UpdateTask} class in Java represents a task that periodically
	 * updates the temperature value of a temperature sensor.
	 * 
	 * @see TimerTask
	 */
	private class UpdateTask extends TimerTask {
		private EntryTurnstile context = null;

		public UpdateTask(EntryTurnstile context) {
			this.context = context;
		}

		@Override
		public void run() {
			if (random.nextDouble() < DOWN_PROBABILITY) {
				setDown(!isDown());
				System.out.println(
						"\033[0;33mEntryTurnstile state is changed: " + (isDown() ? "DOWN" : "UP") + "\033[0m");
			}
			this.context.changed();
		}
	}
}
