package it.unipr.digiorgio.smartvillage.client;

import java.util.Random;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.CoAP.Code;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Request;
import org.json.JSONObject;


/**
 * The {@code ChlorineMixer1} class in Java simulates monitoring and adjusting chlorine levels in a smart
 * village system for Olympic Pool, with failure and recovery probabilities included.
 * 
 * The ChlorineMixer1 class is a CoAP client that observes the Chlorine1 resource and adjusts the chlorine
 * level if it falls below a certain threshold. The class simulates a failure and recovery scenario for the
 * Chlorine1 mixer, where the mixer has a 5% probability of failing and a 20% probability of recovering.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ChlorineMixer1 {

    private static final double THRESHOLD = 1.00; // Threshold chlorine level for Olympic Pool
    private static final double FAILURE_PROBABILITY = 0.05; // 5% probability of failure
    private static final double RECOVERY_PROBABILITY = 0.20; // 20% probability of recovery
    private static final Random RANDOM = new Random();
    private static boolean isDown = false;

    public static void main(String[] args) throws InterruptedException {

        CoapClient client = new CoapClient("coap://localhost:5684/chlorine1");
        System.out.println("Chlorine1 Mixer started.");

        client.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {
                if (response == null || response.getResponseText() == null) {
                    System.err.println("Received null response or response text.");
                    return;
                }
                // Simulate failure and recovery
                if (isDown) {
                    System.out.println("\u001B[31mChlorine1 Mixer is down.\u001B[0m");
                    // Attempt to recover
                    if (RANDOM.nextDouble() < RECOVERY_PROBABILITY) {
                        isDown = false;
                        System.out.println("\u001B[32mChlorine1 Mixer has recovered.\u001B[0m");
                    }
                    return;
                } else {
                    // Simulate failure
                    if (RANDOM.nextDouble() < FAILURE_PROBABILITY) {
                        isDown = true;
                        System.out.println("\u001B[31mChlorine1 Mixer has gone down.\u001B[0m");
                        return;
                    }
                }

                String responseText = response.getResponseText();
                JSONObject jsonresponse = new JSONObject(responseText);
                double chlorine = jsonresponse.getDouble("Chlorine");

                System.out.println("\n");
                System.out.println("=====================================");
                System.out.println("Observed Chlorine1: " + String.format("%.2f", chlorine)+" ppm");

                if (chlorine < THRESHOLD) {
                    System.out.println("Chlorine1 level is below threshold. Adding chlorine...");

                    chlorine += 0.20; // Add 0.20 to the current chlorine level

                    System.out.println(
                            "\u001B[33mChlorine1 increased to: " + String.format("%.2f", chlorine) + " ppm\u001B[0m");

                    // Create a POST request
                    Request request = new Request(Code.POST);
                    JSONObject jsonPayload = new JSONObject();
                    jsonPayload.put("Chlorine", chlorine);
                    request.setPayload(jsonPayload.toString());
                    request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

                    // Send the POST request
                    client.advanced(request);
                } else {
                    System.out.println("Chlorine1 level is now above or equal threshold.");
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing the resource.");
            }
        });

        while (true) {
            // Keep the client running for 20 minutes
            Thread.sleep(1200000);
        }
    }
}
