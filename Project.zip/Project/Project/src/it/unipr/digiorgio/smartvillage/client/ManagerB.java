package it.unipr.digiorgio.smartvillage.client;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapObserveRelation;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.CoAP.Code;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.json.JSONObject;

/**
 * The {@code ManagerB} class is a CoAP client that observes entry and exit turnstiles, as well as pool sensors, to
 * monitor the flow of people and pool conditions. The class also simulates manual intervention for turnstiles
 * and adjusts pool conditions if they fall below certain thresholds.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ManagerB {

    private static CoapObserveRelation entryObserveRelation; // Observe relation for entry turnstile
    private static CoapObserveRelation exitObserveRelation; // Observe relation for exit turnstile

    private static Integer lastEntry = null;
    private static Integer lastExit = null;

    // Olympic pool settings
    private static final double TEMP1_THRESHOLD = 25.0;
    private static final double CHLORINE1_THRESHOLD = 1.00;
    private static final double TEMP1_DRASTIC = 28.0;
    private static final double CHLORINE1_DRASTIC = 2;

    // Lagoon pool settings
    private static final double TEMP2_THRESHOLD = 28.0;
    private static final double CHLORINE2_THRESHOLD = 1.0;
    private static final double TEMP2_DRASTIC = 32.0;
    private static final double CHLORINE2_DRASTIC = 1.5;

    // Kids pool settings
    private static final double TEMP3_THRESHOLD = 30.0;
    private static final double CHLORINE3_THRESHOLD = 1.0;
    private static final double TEMP3_DRASTIC = 34.0;
    private static final double CHLORINE3_DRASTIC = 1.5;

    public static void main(String[] args) throws InterruptedException {
        System.out.println("ManagerB started.");

        // Initialize turnstile clients
        CoapClient entryTurnstileClient = new CoapClient("coap://localhost:5683/entry");
        CoapClient exitTurnstileClient = new CoapClient("coap://localhost:5683/exit");

        // Initialize pool sensor clients
        CoapClient tempClient1 = new CoapClient("coap://localhost:5684/temperature1");
        CoapClient chlorineClient1 = new CoapClient("coap://localhost:5684/chlorine1");
        CoapClient tempClient2 = new CoapClient("coap://localhost:5685/temperature2");
        CoapClient chlorineClient2 = new CoapClient("coap://localhost:5685/chlorine2");
        CoapClient tempClient3 = new CoapClient("coap://localhost:5686/temperature3");
        CoapClient chlorineClient3 = new CoapClient("coap://localhost:5686/chlorine3");

        // Observe turnstiles
        observeEntryTurnstile(entryTurnstileClient);
        observeExitTurnstile(exitTurnstileClient);

        // Observe pool sensors
        observePoolSensors(tempClient1, chlorineClient1);
        observePoolSensors(tempClient2, chlorineClient2);
        observePoolSensors(tempClient3, chlorineClient3);

        // Keep the manager running
        while (true) {
            Thread.sleep(10000);
        }
    }

    /**
     * Observe the entry turnstile.
     * 
     * @param client the CoAP client for the entry turnstile
     */
    private static void observeEntryTurnstile(CoapClient client) {
        entryObserveRelation = client.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {

                String payload = response.getResponseText();
                JSONObject jsonPayload = new JSONObject(payload);

                if (response.getCode() == ResponseCode.SERVICE_UNAVAILABLE) {
                    System.err.println("EntryTurnstile is down. Attempting to manually override.");

                    // take memberId from the response
                    String block_member = jsonPayload.getString("memberId");

                    // System.out.println(block_member);

                    openTurnstileManually(client, "entry", block_member); // manually open the turnstile

                } else {
                    Integer totalEntries = jsonPayload.getInt("Total Entries");
                    // System.out.println("Total entries: " + totalEntries);
                    lastEntry = totalEntries;
                    printObservation();
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing entry turnstile " + client.getURI());
            }
        });
    }

    /**
     * Observe the exit turnstile.
     * 
     * @param client the CoAP client for the exit turnstile
     */
    private static void observeExitTurnstile(CoapClient client) {
        exitObserveRelation = client.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {

                String payload = response.getResponseText();
                JSONObject jsonPayload = new JSONObject(payload);

                if (response.getCode() == ResponseCode.SERVICE_UNAVAILABLE) {
                    System.err.println("ExitTurnstile is down. Attempting to manually override.");

                    // take memberId from the response
                    String block_member = jsonPayload.getString("memberId");

                    // System.out.println(block_member);

                    openTurnstileManually(client, "exit", block_member); // manually open the turnstile

                } else {
                    Integer totalExits = jsonPayload.getInt("Total Exits");
                    // System.out.println("Total exits: " + totalExits);
                    lastExit = totalExits;
                    printObservation();
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing exit turnstile " + client.getURI());

            }
        });
    }

    /**
     * Print the observation of the turnstiles.
     */
    private static void printObservation() {
        if (lastEntry != null && lastExit != null) {
            System.out.println("\033[0;32m==============================\033[0m");
            System.out.println("Total entries: " + lastEntry);
            System.out.println("Total exits: " + lastExit);
            System.out.println("Total people inside: " + (lastEntry - lastExit));
            System.out.println("\033[0;32m==============================\033[0m \n");

            lastEntry = null;
            lastExit = null;
        }
    }

    /**
     * Observe the pool sensors.
     * 
     * @param tempClient     the CoAP client for the temperature sensor
     * @param chlorineClient the CoAP client for the chlorine sensor
     */
    private static void observePoolSensors(CoapClient tempClient, CoapClient chlorineClient) {
        tempClient.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {

                String responseText = response.getResponseText();
                JSONObject jsonresponse = new JSONObject(responseText);
                double temperature = jsonresponse.getDouble("Temperature");
                double threshold = 0;
                double drasticMeasure = 0;
                String message = "";

                // set the threshold and drastic measure based on the pool
                if (tempClient.getURI().contains("temperature1")) {
                    threshold = TEMP1_THRESHOLD;
                    drasticMeasure = TEMP1_DRASTIC;
                    message = "Temperature1 critically low. Applying drastic measure.\n";
                } else if (tempClient.getURI().contains("temperature2")) {
                    threshold = TEMP2_THRESHOLD;
                    drasticMeasure = TEMP2_DRASTIC;
                    message = "Temperature2 critically low. Applying drastic measure.\n";
                } else if (tempClient.getURI().contains("temperature3")) {
                    threshold = TEMP3_THRESHOLD;
                    drasticMeasure = TEMP3_DRASTIC;
                    message = "Temperature3 critically low. Applying drastic measure.\n";
                }

                if (temperature < threshold - 2.0) {
                    // Drastic measure
                    System.err.println(message);

                    // Create a POST request
                    Request request = new Request(Code.POST);
                    JSONObject jsonPayload = new JSONObject();
                    jsonPayload.put("Temperature", drasticMeasure);
                    request.setPayload(jsonPayload.toString());
                    request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

                    // Send the POST request
                    tempClient.advanced(request);
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing temperature sensor.");
            }
        });

        chlorineClient.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {

                String responseText = response.getResponseText();
                JSONObject jsonresponse = new JSONObject(responseText);
                double chlorine = jsonresponse.getDouble("Chlorine");
                double threshold = 0;
                double drasticMeasure = 0;
                String message = "";

                // set the threshold and drastic measure based on the pool
                if (chlorineClient.getURI().contains("chlorine1")) {
                    threshold = CHLORINE1_THRESHOLD;
                    drasticMeasure = CHLORINE1_DRASTIC;
                    message = "Chlorine1 level critically low. Applying drastic measure.\n";
                } else if (chlorineClient.getURI().contains("chlorine2")) {
                    threshold = CHLORINE2_THRESHOLD;
                    drasticMeasure = CHLORINE2_DRASTIC;
                    message = "Chlorine2 level critically low. Applying drastic measure.\n";
                } else if (chlorineClient.getURI().contains("chlorine3")) {
                    threshold = CHLORINE3_THRESHOLD;
                    drasticMeasure = CHLORINE3_DRASTIC;
                    message = "Chlorine3 level critically low. Applying drastic measure.\n";
                }

                if (chlorine < threshold - 0.2) {
                    // Drastic measure
                    System.err.println(message);

                    // Create a POST request
                    Request request = new Request(Code.POST);
                    JSONObject jsonPayload = new JSONObject();
                    jsonPayload.put("Chlorine", drasticMeasure);
                    request.setPayload(jsonPayload.toString());
                    request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

                    // Send the POST request
                    chlorineClient.advanced(request);
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing chlorine sensor.");
            }
        });
    }

    /**
     * Reobserve the entry turnstile.
     * 
     * @param client the CoAP client for the entry turnstile
     */
    private static void reobserveEntryTurnstile(CoapClient client) {
        if (entryObserveRelation != null) {
            entryObserveRelation.reactiveCancel();
        }
        observeEntryTurnstile(client);
    }

    /**
     * Reobserve the exit turnstile.
     * 
     * @param client the CoAP client for the exit turnstile
     */
    private static void reobserveExitTurnstile(CoapClient client) {
        if (exitObserveRelation != null) {
            exitObserveRelation.reactiveCancel();
        }
        observeExitTurnstile(client);
    }

    /**
     * Open the turnstile manually.
     * 
     * @param client        the CoAP client for the turnstile
     * @param turnstileType the type of turnstile (entry or exit)
     * @param memberId      the member ID
     */
    private static void openTurnstileManually(CoapClient client, String turnstileType, String memberId) {

        System.out.println("Manually opening " + turnstileType + " turnstile for member ID: " + memberId + ".\n");

        // Create a POST request to simulate manual intervention
        Request request = new Request(Code.POST);
        JSONObject jsonPayload = new JSONObject();
        jsonPayload.put("memberId", memberId);
        jsonPayload.put("manualOverride", true);
        request.setPayload(jsonPayload.toString());
        request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

        // Send the POST request
        client.advanced(request);

        // Reobserve the turnstile after POST request
        if (turnstileType.equals("entry")) {
            reobserveEntryTurnstile(client);
        } else {
            reobserveExitTurnstile(client);
        }
    }

}
