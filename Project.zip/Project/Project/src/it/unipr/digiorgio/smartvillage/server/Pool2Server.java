package it.unipr.digiorgio.smartvillage.server;

import org.eclipse.californium.core.CoapServer;
import it.unipr.digiorgio.smartvillage.server.resources.ChlorineSensor;
import it.unipr.digiorgio.smartvillage.server.resources.TemperatureSensor;

/**
 * The {@code Pool2Server} class extends CoapServer and sets up temperature and chlorine sensors for Lagoon pool.
 * The server is running on port 5685.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class Pool2Server extends CoapServer {

	public static void main(String[] args) {

		CoapServer server = new CoapServer(5685);

		// Lagoon pool
		TemperatureSensor tempSensor2 = new TemperatureSensor("temperature2", 32.0);
		ChlorineSensor chlorineSensor2 = new ChlorineSensor("chlorine2", 1.5);

		// Set observable
		tempSensor2.setObservable(true);
		tempSensor2.getAttributes().setObservable();

		chlorineSensor2.setObservable(true);
		chlorineSensor2.getAttributes().setObservable();

		// Add resources to the server
		server.add(tempSensor2);
		server.add(chlorineSensor2);

		server.start();
		System.out.println("Pool2Server is running...");
	}

}
