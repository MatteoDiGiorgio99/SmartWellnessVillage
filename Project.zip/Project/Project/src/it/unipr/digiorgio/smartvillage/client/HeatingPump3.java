package it.unipr.digiorgio.smartvillage.client;

import java.util.Random;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.CoAP.Code;
import org.json.JSONObject;

/**
 * The {@code HeatingPump3} class in Java simulates a heating pump system that
 * monitors temperature and
 * adjusts heating based on thresholds for Kids Pool, with failure and recovery
 * simulations included.
 * 
 * The HeatingPump3 class is a CoAP client that observes the Temperature3
 * resource and adjusts the temperature
 * if it falls below a certain threshold. The class simulates a failure and
 * recovery scenario for the heating
 * pump, where the pump has a 5% probability of failing and a 20% probability of
 * recovering.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class HeatingPump3 {

    private static final double THRESHOLD = 30.0; // Threshold temperature for Kids Pool
    private static final double FAILURE_PROBABILITY = 0.05; // 5% probability of failure
    private static final double RECOVERY_PROBABILITY = 0.20; // 20% probability of recovery
    private static final Random RANDOM = new Random();
    private static boolean isDown = false;

    public static void main(String[] args) throws InterruptedException {

        CoapClient client = new CoapClient("coap://localhost:5686/temperature3");
        System.out.println("Heating Pump3 started.");

        client.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {
                if (response == null || response.getResponseText() == null) {
                    System.err.println("Received null response or response text.");
                    return;
                }

                // Simulate failure and recovery
                if (isDown) {
                    System.out.println("\u001B[31mHeating Pump3 is down.\u001B[0m");
                    // Attempt to recover
                    if (RANDOM.nextDouble() < RECOVERY_PROBABILITY) {
                        isDown = false;
                        System.out.println("\u001B[32mHeating Pump3 has recovered.\u001B[0m");
                    }
                    return;
                } else {
                    // Simulate failure
                    if (RANDOM.nextDouble() < FAILURE_PROBABILITY) {
                        isDown = true;
                        System.out.println("\u001B[31mHeating Pump3 has gone down.\u001B[0m");
                        return;
                    }
                }

                String content = response.getResponseText();
                JSONObject jsonresponse = new JSONObject(content);
                double temperature = jsonresponse.getDouble("Temperature");

                System.out.println("\n");
                System.out.println("=====================================");
                System.out.println("Observed Temperature3: " + temperature + " °C");

                if (temperature < THRESHOLD) {
                    System.out.println("Temperature3 below threshold. Heating the pool.");

                    temperature += 1; // Increase the temperature by 1

                    System.out.println("\u001B[33mTemperature3 increased to: " + temperature + " °C\u001B[0m");

                    // Create a POST request
                    Request request = new Request(Code.POST);
                    JSONObject jsonPayload = new JSONObject();
                    jsonPayload.put("Temperature", temperature);
                    request.setPayload(jsonPayload.toString());
                    request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

                    // Send the POST request
                    client.advanced(request);
                } else {
                    System.out.println("Temperature3 above threshold. Stopping the heating pump.");
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing the resource.");
            }
        });
        while (true) {
            // Keep the client running for 20 minutes
            Thread.sleep(1200000);
        }
    }
}
