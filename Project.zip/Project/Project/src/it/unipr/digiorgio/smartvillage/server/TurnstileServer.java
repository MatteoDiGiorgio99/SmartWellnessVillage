package it.unipr.digiorgio.smartvillage.server;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.californium.core.CoapServer;
import it.unipr.digiorgio.smartvillage.server.resources.EntryTurnstile;
import it.unipr.digiorgio.smartvillage.server.resources.ExitTurnstile;

/**
 * The {@code TurnstileServer} class extends CoapServer and sets up entry and exit turnstiles for a smart wellness village server.
 * The server is running on port 5683.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class TurnstileServer extends CoapServer {

    public static void main(String[] args) {
        // Set log level
        Logger.getLogger("org.eclipse.californium.core").setLevel(Level.WARNING);

        CoapServer server = new CoapServer(5683);

        // Entry and exit turnstiles
        EntryTurnstile entryTurnstile = new EntryTurnstile("entry");
        ExitTurnstile exitTurnstile = new ExitTurnstile("exit");

        // Set observable
        entryTurnstile.setObservable(true);
        entryTurnstile.getAttributes().setObservable();

        exitTurnstile.setObservable(true);
        exitTurnstile.getAttributes().setObservable();

        // Add resources to the server
        server.add(entryTurnstile);
        server.add(exitTurnstile);

        server.start();
        System.out.println("TurnstileServer is running...");

    }
}
