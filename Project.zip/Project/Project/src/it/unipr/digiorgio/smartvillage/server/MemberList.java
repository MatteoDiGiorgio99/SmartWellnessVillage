package it.unipr.digiorgio.smartvillage.server;

import java.util.HashSet;
import java.util.Set;

/**
 * The {@code MemberList} class is a singleton class that manages a set of member IDs with methods to add,
 * remove, and check for the presence of a member ID.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class MemberList {

    private static MemberList instance;
    private final Set<String> memberIds;

    /**
     * Constructs a new instance of the {@code MemberList} class.
     */
    private MemberList() {
        memberIds = new HashSet<>();
    }

    /**
     * Returns the instance of the {@code MemberList} class.
     * 
     * @return the instance of the {@code MemberList} class
     */
    public static synchronized MemberList getInstance() {
        if (instance == null) {
            instance = new MemberList();
        }
        return instance;
    }

    /**
     * Adds a member ID to the set of member IDs.
     * 
     * @param memberId the member ID to add
     * @return {@code true} if the member ID was added to the set, {@code false}
     *         otherwise
     */
    public synchronized boolean addMember(String memberId) {
        return memberIds.add(memberId);
    }

    /**
     * Removes a member ID from the set of member IDs.
     * 
     * @param memberId the member ID to remove
     * @return {@code true} if the member ID was removed from the set, {@code false}
     *         otherwise
     */
    public synchronized boolean removeMember(String memberId) {
        return memberIds.remove(memberId);
    }

    /**
     * Checks if a member ID is present in the set of member IDs.
     * 
     * @param memberId the member ID to check
     * @return {@code true} if the member ID is present in the set, {@code false}
     *         otherwise
     */
    public synchronized boolean isMemberPresent(String memberId) {
        return memberIds.contains(memberId);
    }
}
