package it.unipr.digiorgio.smartvillage.client;

import java.util.Random;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.CoAP.Code;
import org.json.JSONObject;

/**
 * The {@code HeatingPump2} class in Java represents a CoAP client for
 * monitoring and controlling a heating
 * pump based on temperature observations for Lagoon Pool, with simulated
 * failure and recovery scenarios.
 * 
 * The HeatingPump2 class is a CoAP client that observes the Temperature2
 * resource and adjusts the temperature
 * if it falls below a certain threshold. The class simulates a failure and
 * recovery scenario for the heating
 * pump, where the pump has a 5% probability of failing and a 20% probability of
 * recovering.
 * 
 * @author Matteo Di Giorgio 353719
 * 
 */
public class HeatingPump2 {

    private static final double THRESHOLD = 28.0; // Threshold temperature for Lagoon Pool
    private static final double FAILURE_PROBABILITY = 0.05; // 5% probability of failure
    private static final double RECOVERY_PROBABILITY = 0.20; // 20% probability of recovery
    private static final Random RANDOM = new Random();
    private static boolean isDown = false;

    public static void main(String[] args) throws InterruptedException {

        CoapClient client = new CoapClient("coap://localhost:5685/temperature2");
        System.out.println("Heating Pump2 started.");

        client.observe(new CoapHandler() {
            @Override
            public void onLoad(CoapResponse response) {
                if (response == null || response.getResponseText() == null) {
                    System.err.println("Received null response or response text.");
                    return;
                }

                // Simulate failure and recovery
                if (isDown) {
                    System.out.println("\u001B[31mHeating Pump2 is down.\u001B[0m");
                    // Attempt to recover
                    if (RANDOM.nextDouble() < RECOVERY_PROBABILITY) {
                        isDown = false;
                        System.out.println("\u001B[32mHeating Pump2 has recovered.\u001B[0m");
                    }
                    return;
                } else {
                    // Simulate failure
                    if (RANDOM.nextDouble() < FAILURE_PROBABILITY) {
                        isDown = true;
                        System.out.println("\u001B[31mHeating Pump2 has gone down.\u001B[0m");
                        return;
                    }
                }

                String content = response.getResponseText();
                JSONObject jsonresponse = new JSONObject(content);
                double temperature = jsonresponse.getDouble("Temperature");

                System.out.println("\n");
                System.out.println("=====================================");
                System.out.println("Observed Temperature2: " + temperature + " °C");

                if (temperature < THRESHOLD) {
                    System.out.println("Temperature2 below threshold. Heating the pool.");

                    temperature += 1; // Increase the temperature by 1

                    System.out.println("\u001B[33mTemperature2 increased to: " + temperature + " °C\u001B[0m");

                    // Create a POST request
                    Request request = new Request(Code.POST);
                    JSONObject jsonPayload = new JSONObject();
                    jsonPayload.put("Temperature", temperature);
                    request.setPayload(jsonPayload.toString());
                    request.getOptions().setContentFormat(MediaTypeRegistry.APPLICATION_JSON);

                    // Send the POST request
                    client.advanced(request);
                } else {
                    System.out.println("Temperature2 above threshold. Stopping the heating pump.");
                }
            }

            @Override
            public void onError() {
                System.err.println("Error observing the resource.");
            }
        });
        while (true) {
            // Keep the client running for 20 minutes
            Thread.sleep(1200000);
        }
    }
}