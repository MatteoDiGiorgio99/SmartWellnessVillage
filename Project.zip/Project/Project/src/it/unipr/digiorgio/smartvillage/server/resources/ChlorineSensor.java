package it.unipr.digiorgio.smartvillage.server.resources;

import java.util.Timer;
import java.util.TimerTask;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.json.JSONObject;

/**
 * The {@code ChlorineSensor} class represents a CoAP resource for monitoring and updating chlorine levels,
 * with periodic automatic updates.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ChlorineSensor extends CoapResource {

    private double chlorine;

    /**
     * Constructs a new instance of the {@code ChlorineSensor} class with the
     * specified name and initial chlorine level.
     * 
     * @param name            the name of the resource
     * @param initialChlorine the initial chlorine level
     */
    public ChlorineSensor(String name, double initialChlorine) {
        super(name);
        this.chlorine = initialChlorine;
        Timer timer = new Timer();
        timer.schedule(new UpdateTask(this), 10000, 10000);
    }

    @Override
    public void handleGET(CoapExchange exchange) {
        // Respond with the current chlorine level
        JSONObject jsonResponse = new JSONObject();
        jsonResponse.put("Chlorine", chlorine);
        exchange.respond(ResponseCode.CONTENT, jsonResponse.toString(), MediaTypeRegistry.APPLICATION_JSON);
    }

    @Override
    public void handlePOST(CoapExchange exchange) {
        String payload = exchange.getRequestText();
        try {
            // Parse the JSON payload and set the new chlorine level
            JSONObject jsonPayload = new JSONObject(payload);
            double newChlorine = jsonPayload.getDouble("Chlorine");
            System.out.println("\u001B[32mChlorine set to: " + String.format("%.2f", newChlorine) + " ppm\u001B[0m");
            setChlorine(newChlorine);
            exchange.respond(ResponseCode.CHANGED, "Chlorine level updated");
        } catch (NumberFormatException e) {
            exchange.respond(ResponseCode.BAD_REQUEST, "Invalid chlorine value");
        }
    }

    /**
     * Sets the chlorine level to the specified value.
     * 
     * @param chlorine the new chlorine level
     */
    public void setChlorine(double chlorine) {
        this.chlorine = chlorine;
        changed();
    }

    /**
     * Returns the current chlorine level.
     * 
     * @return the current chlorine level
     */
    public double getChlorine() {
        return chlorine;
    }

    /**
     * The {@code UpdateTask} class represents a task that periodically updates the
     * chlorine level.
     * 
     * @see TimerTask
     */
    private class UpdateTask extends TimerTask {
        private ChlorineSensor context = null;

        public UpdateTask(ChlorineSensor context) {
            this.context = context;
        }

        @Override
        public void run() {
            this.context.chlorine = chlorine - 0.05;
            this.context.changed();
            System.out.println("\u001B[33mChlorine level decreased to: " + String.format("%.2f", this.context.chlorine)
                    + " ppm\u001B[0m");
        }
    }
}
