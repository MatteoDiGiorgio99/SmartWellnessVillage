package it.unipr.digiorgio.smartvillage.server;

import org.eclipse.californium.core.CoapServer;
import it.unipr.digiorgio.smartvillage.server.resources.ChlorineSensor;
import it.unipr.digiorgio.smartvillage.server.resources.TemperatureSensor;

/**
 * The {@code Pool3Server} class extends CoapServer and csets up temperature and chlorine sensors for Kids pool.
 * The server is running on port 5686.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class Pool3Server extends CoapServer {

	public static void main(String[] args) {

		CoapServer server = new CoapServer(5686);
		
		// Kids pool
		TemperatureSensor tempSensor3 = new TemperatureSensor("temperature3", 34.0);
		ChlorineSensor chlorineSensor3 = new ChlorineSensor("chlorine3", 1.5);

		// Set observable
		tempSensor3.setObservable(true);
		tempSensor3.getAttributes().setObservable();

		chlorineSensor3.setObservable(true);
		chlorineSensor3.getAttributes().setObservable();

		// Add resources to the server
		server.add(tempSensor3);
		server.add(chlorineSensor3);

		server.start();
		System.out.println("Pool3Server is running...");
	}
}
